package com.marlabs.roster.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.JTextField;

import java.awt.SystemColor;

import javax.swing.JDesktopPane;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.marlabs.rostar.logger.MyLogger;
import com.marlabs.roster.ReportGenerator;
import com.marlabs.roster.model.ViewData;
import com.marlabs.roster.service.IRawFileHandler;
import com.marlabs.roster.service.impl.RawFileHandler;

import java.awt.Color;

/**
* @author Sushanta.Dehury
*
*/
public class ReportDashboard {
                private static final String METHOD_INIT = "Method initialize";
                private static final String METHOD_EXIT = "Method Exit";
                private static final Logger LOGGER = Logger
                                                .getLogger("ReportDashboard.class");
                private static final String FONTSTYLE = "Tahoma";
                private JFrame frame;
                private JRadioButton devlopment;
                private JRadioButton testing;
                private JComboBox<String> reportType;
                private JComboBox<String> month;
                private JTextField filePath;
                private File selectedFile;
                private IRawFileHandler rowFileHandler;
                private ViewData viewData;
                private ReportGenerator reportGenerator;
                private boolean reportGeneratorFlag;

                /**
                * Launch the application.
                * 
                 * @param args
                */
                public static void main(String[] args) {
                                String methodName = "main";
                                LOGGER.log(Level.INFO, methodName + METHOD_INIT + " "
                                                                + " -ReportDashboard");
                                
                                EventQueue.invokeLater(new Runnable() {
                                                public void run() {
                                                                try {
                                                                                ReportDashboard window = new ReportDashboard();
                                                                                window.frame.setVisible(true);
                                                                } catch (Exception e) {
                                                                                LOGGER.log(Level.FATAL, "Not Invoked",
                                                                                                                new RuntimeException());

                                                                }
                                                }
                                });
                                LOGGER.log(Level.INFO, methodName + " " + METHOD_EXIT + " "
                                                                + " -ReportDashboard");

                }

                /**
                * Create the application.
                */
                public ReportDashboard() {
                                rowFileHandler = new RawFileHandler();
                                viewData = new ViewData();
                                reportGenerator = new ReportGenerator();
                                initialize();
                }

                /**
                * Initialize the contents of the frame.
                */
                private void initialize() {
                                String methodName = "initialize()";
                                LOGGER.log(Level.INFO, methodName + " " + METHOD_INIT
                                                                + " -ReportDashboard");

                                frame = new JFrame("SpringForm");
                                frame.setBounds(350, 150, 687, 459);
                                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                frame.getContentPane().setLayout(null);

                                JLabel lblAttendanceReport = new JLabel("Attendance Report");
                                lblAttendanceReport.setForeground(new Color(30, 144, 255));
                                lblAttendanceReport.setFont(new Font(FONTSTYLE, Font.PLAIN, 25));
                                lblAttendanceReport.setBounds(22, 16, 233, 27);
                                frame.getContentPane().add(lblAttendanceReport);

                                JLabel lblTeam = new JLabel("Team");
                                lblTeam.setFont(new Font(FONTSTYLE, Font.PLAIN, 15));
                                lblTeam.setBounds(21, 84, 57, 14);
                                frame.getContentPane().add(lblTeam);

                                JLabel lblSourseFile = new JLabel("Sourse File");
                                lblSourseFile.setFont(new Font(FONTSTYLE, Font.PLAIN, 15));
                                lblSourseFile.setBounds(21, 123, 82, 14);
                                frame.getContentPane().add(lblSourseFile);

                                JLabel lblReport = new JLabel("Report");
                                lblReport.setFont(new Font(FONTSTYLE, Font.PLAIN, 15));
                                lblReport.setBounds(21, 164, 57, 14);
                                frame.getContentPane().add(lblReport);

                                JLabel label = new JLabel(":");
                                label.setBounds(116, 86, 10, 14);
                                frame.getContentPane().add(label);

                                JLabel labelOne = new JLabel(":");
                                labelOne.setBounds(116, 125, 10, 14);
                                frame.getContentPane().add(labelOne);

                                JLabel labelTwo = new JLabel(":");
                                labelTwo.setBounds(116, 166, 10, 14);
                                frame.getContentPane().add(labelTwo);
                                devlopment = new JRadioButton("Development");
                                devlopment.setSelected(true);
                                devlopment.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent e) {
                                                                if (devlopment.isSelected()) {
                                                                                testing.setSelected(false);
                                                                }
                                                }
                                });
                                devlopment.setFont(new Font(FONTSTYLE, Font.BOLD, 14));
                                devlopment.setBounds(172, 80, 124, 23);
                                frame.getContentPane().add(devlopment);

                                testing = new JRadioButton("Testing");
                                testing.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent e) {
                                                                if (testing.isSelected()) {
                                                                                devlopment.setSelected(false);
                                                                }
                                                }
                                });
                                testing.setFont(new Font(FONTSTYLE, Font.BOLD, 14));
                                testing.setBounds(368, 80, 109, 23);
                                frame.getContentPane().add(testing);

                                reportType = new JComboBox<>();
                                reportType.setFont(new Font(FONTSTYLE, Font.BOLD, 13));
                                reportType.setBounds(172, 163, 124, 27);
                                frame.getContentPane().add(reportType);
                                reportType.addItem("   Daily");
                                reportType.addItem("   Time Sheet");

                                JLabel lblForTheMonth = new JLabel("For the month :");
                                lblForTheMonth.setFont(new Font(FONTSTYLE, Font.PLAIN, 14));
                                lblForTheMonth.setBounds(354, 164, 99, 26);
                                frame.getContentPane().add(lblForTheMonth);

                                month = new JComboBox<>();
                                month.setMaximumRowCount(10);
                                month.setFont(new Font(FONTSTYLE, Font.BOLD, 13));
                                month.setBounds(476, 161, 118, 29);
                                frame.getContentPane().add(month);
                                month.addItem("  Jan   - 01");
                                month.addItem("  Feb   - 02");
                                month.addItem("  Mar  - 03");
                                month.addItem("  Apr   - 04");
                                month.addItem("  May  - 05");
                                month.addItem("  Jun   - 06");
                                month.addItem("  Jul    - 07");
                                month.addItem("  Aug  - 08");
                                month.addItem("  Sep   - 09");
                                month.addItem("  Oct   - 10");
                                month.addItem("  Nov  - 11");
                                month.addItem("  Dec  - 12");

                                JButton btnGenrate = new JButton("Generate");
                                btnGenrate.setFont(new Font(FONTSTYLE, Font.BOLD, 14));
                                btnGenrate.addActionListener(new ActionListener() {
                                                String selectedDepartmentSelected = null;
                                                String selectedReportType = null;
                                                String selectedMonth = null;

                                                public void actionPerformed(ActionEvent arg0) {
                                                                selectedReportType = ((String) reportType.getSelectedItem())
                                                                                                .trim();
                                                                viewData.setReportType(selectedReportType);
                                                                selectedMonth = ((String) month.getSelectedItem()).trim();
                                                                selectedMonth = selectedMonth.replaceAll(" ", "");
                                                                viewData.setMonth(selectedMonth);
                                                                selectedDepartmentSelected = devlopment.isSelected() ? "Development"
                                                                                                : "Testing";
                                                                viewData.setTeam(selectedDepartmentSelected);
                                                                viewData.setSourceFileName(selectedFile.getAbsolutePath());
                                                                
                                                                //Here we are calling controller ReportGenerator class
                                                                System.out.println(viewData);
                                                                
                                                                try {
                     
                                                                                 reportGeneratorFlag =reportGenerator.createReport(rowFileHandler, viewData);

                     if(reportGeneratorFlag== true) {
                            JOptionPane.showMessageDialog(null, "Report is successfully generated . . ", "", JOptionPane.PLAIN_MESSAGE);
                     }
                     }
                     catch(Exception e) {
                            JOptionPane.showMessageDialog(null, e.getMessage().toString(), "", JOptionPane.PLAIN_MESSAGE);
                     }
                     
                                                                LOGGER.log(Level.INFO, "report: " + selectedReportType
                                                                                                + " month: " + selectedMonth + " typeReportSelected: "
                                                                                                + selectedDepartmentSelected + " -ReportDashboard");

                                                }
                                });
                                btnGenrate.setBounds(247, 299, 109, 34);
                                frame.getContentPane().add(btnGenrate);

                                JButton btnBrowse = new JButton("Browse");
                                btnBrowse.addActionListener(e -> {
                                                JFileChooser jFileChooser = new JFileChooser();
                                                int putTextBox = jFileChooser.showOpenDialog(null);
                                                if (putTextBox == JFileChooser.APPROVE_OPTION) {
                                                                selectedFile = jFileChooser.getSelectedFile();
                                                                filePath.setText(selectedFile.getAbsolutePath());
                                                                LOGGER.log(Level.INFO,
                                                                                                "file name : " + selectedFile.getAbsolutePath()
                                                                                                                                + " -ReportDashboard");
                                                }
                                });

                                btnBrowse.setBounds(439, 121, 89, 23);
                                frame.getContentPane().add(btnBrowse);

                                filePath = new JTextField();
                                filePath.setBounds(172, 122, 241, 20);
                                frame.getContentPane().add(filePath);
                                filePath.setColumns(10);

                                JDesktopPane desktopPane = new JDesktopPane();
                                desktopPane.setBackground(SystemColor.activeCaptionBorder);
                                desktopPane.setBounds(10, 49, 651, -6);
                                frame.getContentPane().add(desktopPane);

                                JDesktopPane desktopPaneOne = new JDesktopPane();
                                desktopPaneOne.setBackground(SystemColor.activeCaptionBorder);
                                desktopPaneOne.setBounds(10, 49, 651, 1);
                                frame.getContentPane().add(desktopPaneOne);
                                LOGGER.log(Level.INFO, methodName + "" + "" + METHOD_EXIT + " "
                                                                + "ReportDashboard");

                }
}
