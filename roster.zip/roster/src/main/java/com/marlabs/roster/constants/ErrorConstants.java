package com.marlabs.roster.constants;

/**
 * @author Ranadip.Jha
 *
 */
public class ErrorConstants {
	/**
	 * Given file is not Expected Format(.xls)
	 */
	public static final String ERROR_CODE_501 = "File is not Expected Format(.xls) ...";
	/**
	 * 
	 */
	public static final String ERROR_CODE_502 = "Header text is empty...";
	/**
	 * 
	 */
	public static final String ERROR_CODE_503 = "Heading text is not matched...";
	/**
	 * 
	 */
	public static final String ERROR_CODE_504 = "Input file is Corrupted";
	/**
	 * 
	 */
	public static final String ERROR_CODE_505 = "First row data is empty";
	/**
	 * 
	 */
	public static final String ERROR_CODE_506 = "Next row data is empty";
	/**
	 * 
	 */
	public static final String ERROR_CODE_507 = "Null Value";
	/**
	 * 
	 */
	public static final String ERROR_CODE_508 = "File is not Found";

}
