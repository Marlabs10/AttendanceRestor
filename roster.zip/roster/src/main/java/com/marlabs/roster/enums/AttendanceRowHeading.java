package com.marlabs.roster.enums;

/**
 * @author Sushanta.Dehury
 *
 */
public enum AttendanceRowHeading {

	/**
	 * Emp Name
	 */
	COLUMN_1("Emp Name"),
	/**
	 * Date
	 */
	COLUMN_2("Date"),
	/**
	 * Day
	 */
	COLUMN_3("Day"),
	/**
	 * In Time
	 */
	COLUMN_4("In Time"),
	/**
	 * Out Time
	 */
	COLUMN_5("Out Time"),
	/**
	 * Logged Hours
	 */
	COLUMN_6("Logged Hours"),
	/**
	 * Attendance
	 */
	COLUMN_7("Attendance"),
	/**
	 * Hours Counted
	 */
	COLUMN_8("Hours Counted");

	private String name;

	AttendanceRowHeading(String columnHead) {
		this.name = columnHead;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

}
