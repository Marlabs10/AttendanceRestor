package com.marlabs.roster.service.impl;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.DataFormatter;

import com.marlabs.roster.constants.ErrorConstants;
import com.marlabs.roster.enums.InOutStatus;
import com.marlabs.roster.enums.RawDataHeading;
import com.marlabs.roster.exception.ContentNotFoundException;
import com.marlabs.roster.exception.HeaderNotFoundException;
import com.marlabs.roster.exception.UnSupportedFormatException;
import com.marlabs.roster.model.RawData;
import com.marlabs.roster.model.RawHeaderData;
import com.marlabs.roster.service.IRawFileHandler;
import com.marlabs.roster.util.BaseExcelFileReader;

/**
 * @author Sushanta.Dehury
 *
 */
public class RawFileHandler extends BaseExcelFileReader implements
		IRawFileHandler {
	private static final Logger LOGGER = Logger.getLogger(RawFileHandler.class
			.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";
	private RawData rawRow;
	private RawHeaderData rawHeaderData;
	private int rowPosition;

	// This method will validate the Heading text.
	private boolean validateHeading() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		HSSFRow row = null;

		boolean compareHeadingFlag = false;
		row = sheet.getRow(0);
		int cellCount = RawDataHeading.values().length;
		for (int i = 0; i < cellCount; i++) {
			if (row.getCell(i).getStringCellValue().isEmpty()) {
				throw new HeaderNotFoundException(ErrorConstants.ERROR_CODE_502);
			} else {
				compareHeadingFlag = true;
			}
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return compareHeadingFlag;
	}

	// This method will compare Heading text with expected text.
	private boolean compareHeading() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		HSSFRow row = null;

		boolean compareHeadingFlag = false;
		DataFormatter dataFormatter = new DataFormatter();
		row = sheet.getRow(0);
		RawDataHeading[] enumHeading = RawDataHeading.values();
		int cellSize = enumHeading.length;
		for (int i = 0; i < cellSize; i++) {
			if (dataFormatter.formatCellValue(row.getCell(i)).equals(
					enumHeading[i].getName())) {
				compareHeadingFlag = true;
			} else {
				throw new ContentNotFoundException(
						ErrorConstants.ERROR_CODE_503);
			}
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return compareHeadingFlag;
	}

	// This method will validate the file contents for its validity.
	public boolean validateFile(String rawFileName) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		boolean outputFlag = false;
		int stringLength = rawFileName.length();
		if (!rawFileName.substring(rawFileName.lastIndexOf('.'), stringLength)
				.equals(".xls")) {
			throw new UnSupportedFormatException(ErrorConstants.ERROR_CODE_501);
		}
		fileName = rawFileName;
		POIFSFileSystem poiFile = openFile();
		sheet = getSheet(poiFile);
		boolean compareHeadingFlag = compareHeading();
		boolean validateHeadingFlag = validateHeading();
		if (validateHeadingFlag && compareHeadingFlag) {
			outputFlag = true;
		}
		closeFile(poiFile);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return outputFlag;
	}

	// This method will read the Column Header names.
	public RawHeaderData getHeaderRow() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		rowPosition = 0;
		POIFSFileSystem poiFile = openFile();
		sheet = getSheet(poiFile);
		HSSFRow row = sheet.getRow(rowPosition);
		DataFormatter dataFormatter = new DataFormatter();
		row.forEach(cell -> {
			int cellCount = 0;
			rawHeaderData = new RawHeaderData();
			rawHeaderData.setDate(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setTime(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setEmpid(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setEmpName(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setDepartment(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setGate(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setInOut(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setLocation(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawHeaderData.setRemark(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
		});
		closeFile(poiFile);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return rawHeaderData;
	}

	// Get the first row, which is after the Header row.
	public RawData getFirstRow() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		rowPosition = 1;
		POIFSFileSystem poiFile = openFile();
		sheet = getSheet(poiFile);
		HSSFRow row = sheet.getRow(rowPosition);
		DataFormatter dataFormatter = new DataFormatter();
		row.forEach(cell -> {
			int cellCount = 0;
			rawRow = new RawData();
			rawRow.setDate(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setTime(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setEmpId(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setEmpName(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setDepartment(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setGate(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			if (dataFormatter.formatCellValue(row.getCell(cellCount++)).equals(
					InOutStatus.COLUMN_1.getName())) {
				rawRow.setInOut(InOutStatus.COLUMN_1);
			} else {
				rawRow.setInOut(InOutStatus.COLUMN_2);
			}
			rawRow.setLocation(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
			rawRow.setRemark(dataFormatter.formatCellValue(row
					.getCell(cellCount++)));
		});

		closeFile(poiFile);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return rawRow;
	}

	// Moves to next consecutive row. If end-of-file, then return null.
	public RawData getNextRow() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		rowPosition++;
		POIFSFileSystem poiFile = openFile();
		sheet = getSheet(poiFile);
		HSSFRow row = sheet.getRow(rowPosition);
		DataFormatter dataFormatter = new DataFormatter();
		row.forEach(cell -> {
			int cellCount = 0;
			if (!dataFormatter.formatCellValue(cell).equals("")) {

				rawRow = new RawData();
				rawRow.setDate(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setTime(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setEmpId(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setEmpName(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setDepartment(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setGate(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				if (dataFormatter.formatCellValue(row.getCell(cellCount++))
						.equals(InOutStatus.COLUMN_1.getName())) {
					rawRow.setInOut(InOutStatus.COLUMN_1);
				} else {
					rawRow.setInOut(InOutStatus.COLUMN_2);
				}
				rawRow.setLocation(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
				rawRow.setRemark(dataFormatter.formatCellValue(row
						.getCell(cellCount++)));
			}
		});

		closeFile(poiFile);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return rawRow;
	}

	// This method is use for get all the row count
	public int getTotalRowCount() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		POIFSFileSystem poiFile = openFile();
		sheet = getSheet(poiFile);
		int rowCount = 0;
		for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			if (!sheet.getRow(rowIndex).getCell(0).toString().trim().equals("")) {
				rowCount++;
			}
		}
		closeFile(poiFile);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return rowCount;
	}

}
