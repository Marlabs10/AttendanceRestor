package com.marlabs.roster.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import com.marlabs.roster.enums.AttendanceRowHeading;
import com.marlabs.roster.enums.InOutStatus;
import com.marlabs.roster.model.AttendanceRowData;
import com.marlabs.roster.model.RawData;
import com.marlabs.roster.service.IRawFileHandler;
import com.marlabs.roster.service.IReportGenerator;
import com.marlabs.roster.util.BaseExcelFileWriter;

/**
 * @author Sushanta.Dehury
 *
 */
public class AttendanceReport extends BaseExcelFileWriter implements
		IReportGenerator {
	private static final Logger LOGGER = Logger
			.getLogger(AttendanceReport.class.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";
	private AttendanceRowData reportData;
	private FileOutputStream excelReportFile;

	@SuppressWarnings("unused")
	@Override
	public boolean generateReport(IRawFileHandler rawFile, String month) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		boolean generateFlag = false;
		String hoursCounted = null;
		long totalHour = 0L;
		File directory = new File("AttendanceRoster\\output\\");
		File[] files = directory.listFiles();
		// For reading data for Excel Sheet and putting into Map Collection
		Map<String, List<RawData>> map = null;
		map = readExcelSheetDataToMap(rawFile);
		
		//This is use to hold key as id and value as a Total HoursCounted
		Map<String,Long> totalHoursCountedMap=new LinkedHashMap<>();
		
		// This code is use to iterate that map and calculate the
					// loggedHours
					Map<String, AttendanceRowData> outputMap = new LinkedHashMap<>();//write map
					for (Map.Entry<String, List<RawData>> mapEnter : map.entrySet()) {
						List<RawData> list = mapEnter.getValue();
						int listSize = list.size();
						RawData firstRaw = null;
						RawData secondRaw = null;
						long totalTime = 0L;
						String totalTimeString = null;
						reportData = new AttendanceRowData();

						for (int i = 0; i < listSize; i++) {

							for (int j = i + 1; j < listSize; j++) {
								firstRaw = list.get(i);
								secondRaw = list.get(j);
								if (firstRaw.getInOut().getName()
										.equals(InOutStatus.COLUMN_1.getName())
										&& secondRaw.getInOut().getName()
												.equals(InOutStatus.COLUMN_2.getName())) {
									totalTime = totalTime
											+ calculateTime(firstRaw.getTime(),
													secondRaw.getTime());

								}
								i++;
								break;
							}
						}
						
						//totalHour = totalHour + totalTime;//total hours per day(loggedHours)
						totalTimeString = convertMillisecondToTimeFormat(totalTime);//String value total hours of per day
						//hoursCounted = convertMillisecondToTimeFormat(totalHour);//String total value of hours per month
						
						if(totalHoursCountedMap.containsKey(firstRaw.getEmpId())){
							totalHoursCountedMap.put(firstRaw.getEmpId(), (totalHoursCountedMap.get(firstRaw.getEmpId())+totalTime));
						}else {
							totalHoursCountedMap.put(firstRaw.getEmpId(), totalTime);
						}
						
						reportData.setAttendance("Present");
					
						reportData.setDate(Integer.parseInt(calculateDate(firstRaw
								.getDate())));
					
						reportData.setEmpName(firstRaw.getEmpName());
						reportData.setLoggedHours(totalTimeString);
						reportData.setDay(calculateDay(firstRaw.getDate()));
						reportData.setInTime(list.get(0).getTime());
						reportData.setOutTime(list.get(list.size() - 1).getTime());
						reportData.setEmpId(firstRaw.getEmpId());
						outputMap.put(list.get(0).getEmpId() + ""
								+ list.get(0).getDate(), reportData);
					}

					

					// Here we will write Model to Excel Sheet
					if (files !=null &&files.length > 0) {
						files[0].delete();
						generateFlag = writeDataToExcelSheet(outputMap, month,
								totalHoursCountedMap);
					} else {
						generateFlag = writeDataToExcelSheet(outputMap, month,
								totalHoursCountedMap);
					}

				LOGGER.log(Level.INFO, METHOD_EXIT);

		return generateFlag;
	}

	/**
	 * @param date
	 * @return String
	 */
	// This method is calculate the Date
	public String calculateDate(String date) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		String outputString = date.substring(0, 2);
		LOGGER.log(Level.INFO, METHOD_EXIT);

		return outputString;
	}

	/**
	 * @param dateString
	 * @return String
	 */
	// This method is calculate the Date
	public String calculateDay(String dateString) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		SimpleDateFormat simpleDateFormat = null;
		DateFormat dateFormat = null;
		Date date = null;
		String weekDay = null;
		try {
			simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			date = simpleDateFormat.parse(dateString);
			dateFormat = new SimpleDateFormat("EE");
			weekDay = dateFormat.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);

		return weekDay;
	}

	// This method is use to calculate total loggedHours
	private long calculateTime(String inputTime1, String inputTime2) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		Date date1 = null;
		Date date2 = null;
		long miliSecond = 0L;

		DateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
		DateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");
		try {
			date1 = sdf1.parse(inputTime1);
			date2 = sdf2.parse(inputTime2);

			miliSecond = (date2.getTime() - date1.getTime());

		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);

		return miliSecond;
	}

	// This method is use to convert millisecond to String Time Format
	// (hh:mm:ss)
	private String convertMillisecondToTimeFormat(long miliSecond) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		String totalTime = null;
		totalTime = String.format(
				"%02d:%02d:%02d",
				TimeUnit.MILLISECONDS.toHours(miliSecond),
				TimeUnit.MILLISECONDS.toMinutes(miliSecond)
						- TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS
								.toHours(miliSecond)),
				TimeUnit.MILLISECONDS.toSeconds(miliSecond)
						- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS
								.toMinutes(miliSecond)));
		LOGGER.log(Level.INFO, METHOD_EXIT);

		return totalTime;
	}

	private boolean writeDataToExcelSheet(
			Map<String, AttendanceRowData> mapRaw, String month,
			Map<String,Long> totalHoursCountedMap) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		fileName = "AttendanceRoster\\output\\Attendance-Dev[QA]-Team-" + month + ".xls";
		excelReportFile = openFile();

		int rowNum = 0;
		HSSFRow row = null;
		Cell cell = null;
		AttendanceRowData attendanceRowData;
		boolean writeFlag = false;
		try {
			workBook = new HSSFWorkbook();
			sheet = workBook.createSheet("RMDailyAttendance");
			// This is use to write Header
			row = sheet.createRow(rowNum);
			AttendanceRowHeading[] attendanceRowHeading = AttendanceRowHeading
					.values();
			int headingCount = attendanceRowHeading.length;
			for (int i = 0; i < headingCount; i++) {
				cell = row.createCell(i);
				cell.setCellValue(((String) attendanceRowHeading[i].getName()));
			}
			// this is use to write EveryRow
			for (Map.Entry<String, AttendanceRowData> mapEntry : mapRaw
					.entrySet()) {
				String hoursCounted=null;
				attendanceRowData = mapEntry.getValue();
				if(totalHoursCountedMap.containsKey(attendanceRowData.getEmpId())){
					long totalHoursCounted=totalHoursCountedMap.get(attendanceRowData.getEmpId());
					hoursCounted=convertMillisecondToTimeFormat(totalHoursCounted);
				}
				
				row = sheet.createRow(++rowNum);

				row.createCell(0).setCellValue(attendanceRowData.getEmpName());

				row.createCell(1).setCellValue(attendanceRowData.getDate());
				row.createCell(2).setCellValue(attendanceRowData.getDay());
				row.createCell(3).setCellValue(attendanceRowData.getInTime());
				row.createCell(4).setCellValue(attendanceRowData.getOutTime());
				row.createCell(5).setCellValue(
						attendanceRowData.getLoggedHours());
				row.createCell(6).setCellValue(
						attendanceRowData.getAttendance());

				row.createCell(7).setCellValue(hoursCounted);
			}
			workBook.write(excelReportFile);
			writeFlag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeFile(excelReportFile);
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);

		return writeFlag;
	}

	// This method is used to read Excel Sheet data to map collection
	private Map<String, List<RawData>> readExcelSheetDataToMap(
			IRawFileHandler rawFile) {
		// For reading data for Excel Sheet and putting into Map Collection
		Map<String, List<RawData>> map = null;
		map = new LinkedHashMap<>();
		List<RawData> rawList = null;
		RawData rawData = null;
		int size = rawFile.getTotalRowCount();

		for (int i = 0; i < size; i++) {
			rawData = rawFile.getNextRow();
			if (map.containsKey(rawData.getEmpId() + "" + rawData.getDate())) {
				List<RawData> list = map.get(rawData.getEmpId() + ""
						+ rawData.getDate());
				list.add(rawData);
				map.put(rawData.getEmpId() + "" + rawData.getDate(), list);
			} else {
				rawList = new ArrayList<>();
				rawList.add(rawData);
				map.put(rawData.getEmpId() + "" + rawData.getDate(),
						rawList);
			}
		}

		return map;
	}

}
