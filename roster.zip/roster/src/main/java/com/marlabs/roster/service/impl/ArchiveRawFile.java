package com.marlabs.roster.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.marlabs.roster.service.IArchive;

/**
 * @author Sushanta.Dehury
 *
 */
// This Class would copy processed file into Archive folder
public class ArchiveRawFile implements IArchive {

	String zipFileName;
	String filePath;
	boolean validFolderFlag;
	boolean createFolderFlag;
	boolean fileArchived;

	private static final Logger LOGGER = Logger.getLogger(ArchiveRawFile.class
			.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";

	public boolean archive(Object fileName) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		return validateFolder(fileName.toString());
	}

	// This method validates whether if Folder exists.
	private boolean validateFolder(String fileName) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		/* create a folder for Attendance roster */
		StringBuilder attendanceRosterTargetDirectory = new StringBuilder(
				"AttendanceRoster\\");
		File attendanceRosterFolder = new File(
				attendanceRosterTargetDirectory.toString());
		if (!attendanceRosterFolder.exists()) {
			createFolderGeneral(attendanceRosterFolder);
		}

		/* create a folder for Attendance roster with logs */
		StringBuilder logsTargetDirectory = new StringBuilder(
				"AttendanceRoster\\logs\\");

		File logsFolder = new File(logsTargetDirectory.toString());
		if (!logsFolder.exists()) {
			createFolderGeneral(logsFolder);
		}
		/* create a folder for Attendance roster with bin */
		StringBuilder binTargetDirectory = new StringBuilder(
				"AttendanceRoster\\bin\\");

		File binFolder = new File(binTargetDirectory.toString());
		if (!binFolder.exists()) {
			createFolderGeneral(binFolder);
		}
		/* create a folder for Attendance roster with config inside bin folder */
		StringBuilder configTargetDirectory = new StringBuilder(
				"AttendanceRoster\\bin\\config\\");

		File configFolder = new File(configTargetDirectory.toString());
		if (!configFolder.exists()) {
			createFolderGeneral(configFolder);
		}
		/* create a folder for Attendance roster with Archive */
		StringBuilder archiveTargetDirectory = new StringBuilder(
				"AttendanceRoster\\archive\\");

		File archiveFolder = new File(archiveTargetDirectory.toString());
		if (!archiveFolder.exists()) {
			createFolder(fileName, archiveFolder, archiveTargetDirectory);
		} else {
			genArchiveFileName(fileName, archiveTargetDirectory);
		}
		/* create a folder for Attendance roster with Output */
		StringBuilder ouputTargetDirectory = new StringBuilder("AttendanceRoster\\output\\");
		File outputFolder = new File(ouputTargetDirectory.toString());
		if (!outputFolder.exists()) {
			createFolderGeneral(outputFolder);
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return validFolderFlag;
	}

	// This method creates a folder.
	private boolean createFolder(String fileName, File archiveFolder,
			StringBuilder targetDirectory) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		if (archiveFolder.mkdir()) {
			createFolderFlag = true;
		}
		genArchiveFileName(fileName, targetDirectory);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return createFolderFlag;
	}

	// This method creates a folder.
	private boolean createFolderGeneral(File archiveFolder) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		if (archiveFolder.mkdir()) {
			createFolderFlag = true;
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return createFolderFlag;
	}

	// This method will generates a file name
	// which is used for renaming file.
	// File format would be YYYYMMDDHHMM
	private String genArchiveFileName(String fileName,
			StringBuilder targetDirectory) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		zipFileName = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss").format(
				new Date()).concat(".zip");
		targetDirectory.append(zipFileName);
		writeFile(fileName, targetDirectory);
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return zipFileName;
	}

	// This method would write the file to disk
	private boolean writeFile(String fileName, StringBuilder targetDirectory) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		File fileToZip = new File(fileName);
		try (FileOutputStream fos = new FileOutputStream(
				targetDirectory.toString());
				FileInputStream fis = new FileInputStream(fileToZip);) {
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
			zipOut.putNextEntry(zipEntry);
			byte[] bytes = new byte[1024];
			int length;
			while ((length = fis.read(bytes)) >= 0) {
				zipOut.write(bytes, 0, length);
			}
			zipOut.close();

		} catch (IOException e) {
			LOGGER.log(Level.INFO, e.getMessage());
		}

		LOGGER.log(Level.INFO, METHOD_EXIT);
		return false;
	}

}
