package com.marlabs.roster.service;

/**
 * @author Sushanta.Dehury
 *
 */
public interface IArchive {

	/**
	 * @param fileName
	 * @return boolean
	 */
	public boolean archive(Object fileName);

}
