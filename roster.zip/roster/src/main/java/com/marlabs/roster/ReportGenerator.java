package com.marlabs.roster;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.marlabs.roster.enums.ReportType;
import com.marlabs.roster.model.ViewData;
import com.marlabs.roster.service.IArchive;
import com.marlabs.roster.service.IRawFileHandler;
import com.marlabs.roster.service.IReportGenerator;
import com.marlabs.roster.service.impl.ArchiveRawFile;
import com.marlabs.roster.service.impl.AttendanceReport;
import com.marlabs.roster.service.impl.AttendanceReport;
import com.marlabs.roster.util.BaseExcelFileReader;

/**
 * @author Sushanta.Dehury
 *
 */
public class ReportGenerator {
	private static final Logger LOGGER = Logger
			.getLogger(BaseExcelFileReader.class.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";
	@SuppressWarnings("unused")
	private ReportType reportType;
	@SuppressWarnings("unused")
	private IRawFileHandler rawFile;
	private IArchive archiveRawFile;
	private IReportGenerator reportGenerator;

	/**
	 * @param rawFile
	 * @param viewData
	 * @return boolean
	 */
	public boolean createReport(final IRawFileHandler rawFile, ViewData viewData) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		this.rawFile = rawFile;
		reportGenerator = new AttendanceReport();
		boolean createReportFlag = false;
		if (viewData.getReportType().equals("Daily")) {
			if (rawFile.validateFile(viewData.getSourceFileName())) {
				createReportFlag = true;
				archiveRawFile = new ArchiveRawFile();
				archiveRawFile.archive(viewData.getSourceFileName());
				reportGenerator.generateReport(rawFile, viewData.getMonth());
			}
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return createReportFlag;
	}
}
