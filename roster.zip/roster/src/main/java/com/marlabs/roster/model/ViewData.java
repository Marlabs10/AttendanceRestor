package com.marlabs.roster.model;


/**
 * @author Sushanta.Dehury
 *
 */
public class ViewData {
       private String team;
       private String sourceFileName;
       private String reportType;
       private String month;
       /**
       * @return team
       */
       public String getTeam() {
              return team;
       }
       /**
       * @param team
       */
       public void setTeam(String team) {
              this.team = team;
       }
       /**
       * @return string
       */
       public String getSourceFileName() {
              return sourceFileName;
       }
       /**
       * @param sourceFileName
       */
       public void setSourceFileName(String sourceFileName) {
              this.sourceFileName = sourceFileName;
       }
       /**
       * @return reportType
       */
       public String getReportType() {
              return reportType;
       }
       /**
       * @param reportType
       */
       public void setReportType(String reportType) {
              this.reportType = reportType;
       }
       /**
       * @return report
       */
       public String getMonth() {
              return month;
       }
       /**
       * @param month
       */
       public void setMonth(String month) {
              this.month = month;
       }
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ViewData [team=" + team + ", sourceFileName=" + sourceFileName
				+ ", reportType=" + reportType + ", month=" + month + "]";
	}
       
       

}

