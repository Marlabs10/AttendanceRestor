package com.marlabs.roster.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.marlabs.roster.constants.ErrorConstants;

// This is a Base Class is for reading Excel file.
/**
 * @author Ranadip.Jha
 *
 */
public abstract class BaseExcelFileReader {

	protected String fileName;
	protected HSSFWorkbook workBook;
	protected HSSFSheet sheet;

	private static final Logger LOGGER = Logger
			.getLogger(BaseExcelFileReader.class.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";
	private static final String FILE_NOT_FOUND = "File is not in expected format";

	// This method will open Excel file for reading.
	protected POIFSFileSystem openFile() {

		LOGGER.log(Level.INFO, METHOD_INIT);
		POIFSFileSystem poiFile = null;
		File fileInput = null;
		try {
			fileInput = new File(fileName);
			if (!fileInput.exists()) {
				throw new FileNotFoundException(ErrorConstants.ERROR_CODE_507);
			}
			poiFile = new POIFSFileSystem(fileInput);
		} catch (IOException e) {
			LOGGER.log(Level.FATAL, FILE_NOT_FOUND, new IOException());
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return poiFile;
	}

	// This method will close Excel file.

	protected void closeFile(POIFSFileSystem poiFile) {
		LOGGER.log(Level.INFO, METHOD_INIT);

		try {
			poiFile.close();
		} catch (IOException e) {
			LOGGER.log(Level.FATAL, FILE_NOT_FOUND, new IOException());
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);

	}

	// This method is use to create HSSFSheet Object
	protected HSSFSheet getSheet(POIFSFileSystem poiFile) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		try {
			workBook = new HSSFWorkbook(poiFile);
			sheet = workBook.getSheetAt(0);
		} catch (IOException e) {
			LOGGER.log(Level.FATAL, FILE_NOT_FOUND, new IOException());
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return sheet;
	}

}
