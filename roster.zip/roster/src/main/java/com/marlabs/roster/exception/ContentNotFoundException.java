package com.marlabs.roster.exception;

/**
 * @author Sushanta.Dehury
 *
 */
public class ContentNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public ContentNotFoundException() {
	}

	/**
	 * @param arg0
	 */
	public ContentNotFoundException(String arg0) {
		super(arg0);
	}


}
