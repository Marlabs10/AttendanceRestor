package com.marlabs.roster.exception;

/**
 * @author Sushanta.Dehury
 *
 */
public class HeaderNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public HeaderNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public HeaderNotFoundException(String message) {
		super(message);
	}

}
