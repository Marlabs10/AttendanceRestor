package com.marlabs.roster.model;

/**
 * @author Sushanta.Dehury
 *
 */
public class RawHeaderData {
	private String Date;
	private String Time;
	private String Empid;
	private String EmpName;
	private String Department;
	private String Gate;
	private String InOut;
	private String Location;
	private String Remark;
	/**
	 * @return the date
	 */
	public String getDate() {
		return Date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		Date = date;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return Time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		Time = time;
	}
	/**
	 * @return the empid
	 */
	public String getEmpid() {
		return Empid;
	}
	/**
	 * @param empid the empid to set
	 */
	public void setEmpid(String empid) {
		Empid = empid;
	}
	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return EmpName;
	}
	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return Department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		Department = department;
	}
	/**
	 * @return the gate
	 */
	public String getGate() {
		return Gate;
	}
	/**
	 * @param gate the gate to set
	 */
	public void setGate(String gate) {
		Gate = gate;
	}
	/**
	 * @return the inOut
	 */
	public String getInOut() {
		return InOut;
	}
	/**
	 * @param inOut the inOut to set
	 */
	public void setInOut(String inOut) {
		InOut = inOut;
	}
	/**
	 * @return the location
	 */
	public String getLocation() {
		return Location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		Location = location;
	}
	/**
	 * @return the remark
	 */
	public String getRemark() {
		return Remark;
	}
	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		Remark = remark;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RawHeaderData [Date=" + Date + ", Time=" + Time + ", Empid="
				+ Empid + ", EmpName=" + EmpName + ", Department=" + Department
				+ ", Gate=" + Gate + ", InOut=" + InOut + ", Location="
				+ Location + ", Remark=" + Remark + "]";
	}
	
	
}
