package com.marlabs.roster.service;


/**
 * @author Sushanta.Dehury
 *
 */
public interface IReportGenerator {
	/**
	 * @param rawFile
	 * @param month 
	 * @return boolean
	 */
	public boolean generateReport(IRawFileHandler rawFile,String month);
}
