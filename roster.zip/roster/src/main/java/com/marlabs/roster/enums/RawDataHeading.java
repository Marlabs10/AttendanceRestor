package com.marlabs.roster.enums;

/**
 * @author Sushanta.Dehury
 *
 */
public enum RawDataHeading {

	/**
	 * Date
	 */
	COLUMN_1("Date"),
	/**
	 * Time
	 */
	COLUMN_2("Time"),
	/**
	 * Empid
	 */
	COLUMN_3("Empid"),
	/**
	 * EmpName
	 */
	COLUMN_4("EmpName"),
	/**
	 * Department
	 */
	COLUMN_5("Department"),
	/**
	 * Gate
	 */
	COLUMN_6("Gate"),
	/**
	 * InOut
	 */
	COLUMN_7("InOut"),
	/**
	 * Location
	 */
	COLUMN_8("Location"),
	/**
	 * Remark
	 */
	COLUMN_9("Remark");

	private String name;

	RawDataHeading(String columnHead) {
		this.name = columnHead;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
}
