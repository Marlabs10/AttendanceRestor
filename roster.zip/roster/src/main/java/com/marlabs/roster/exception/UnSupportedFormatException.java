package com.marlabs.roster.exception;

/**
 * @author Sushanta.Dehury
 *
 */
public class UnSupportedFormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public UnSupportedFormatException() {

	}

	/**
	 * @param message
	 */
	public UnSupportedFormatException(String message) {
		super(message);
	}

}
