package com.marlabs.roster.enums;

/**
 * @author Sushanta.Dehury
 *
 */
public enum ReportType {
	/**
	 * Attendance
	 */
	COLUMN_1("Attendance"),
	/**
	 * TimeSheet
	 */
	COLUMN_2("TimeSheet");
	
	private String name;

	ReportType(String reportType) {
		this.name=reportType;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	
}