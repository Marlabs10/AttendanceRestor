package com.marlabs.roster.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * @author Sushanta.Dehury
 *
 */
public abstract class BaseExcelFileWriter {
	private static final Logger LOGGER = Logger
			.getLogger(BaseExcelFileReader.class.getName());
	private static final String METHOD_INIT = "Method initialize";
	private static final String METHOD_EXIT = "Method Exit";
	protected String fileName;
	protected HSSFWorkbook workBook;
	protected HSSFSheet sheet;
	protected HSSFRow row;

	// This method will open the Excel File
	protected FileOutputStream openFile() {
		LOGGER.log(Level.INFO, METHOD_INIT);
		FileOutputStream fileOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(new File(fileName));
		} catch (FileNotFoundException e) {
			LOGGER.log(Level.FATAL, new FileNotFoundException());
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
		return fileOutputStream;
	}

	// This method will close the Excel File
	protected void closeFile(FileOutputStream fileOutputStream) {
		LOGGER.log(Level.INFO, METHOD_INIT);
		try {
			fileOutputStream.close();
		} catch (IOException e) {
			LOGGER.log(Level.FATAL, new IOException());
		}
		LOGGER.log(Level.INFO, METHOD_EXIT);
	}
}
