package com.marlabs.roster.enums;

/**
 * @author Sushanta.Dehury
 *
 */
public enum InOutStatus {

	/**
	 * In
	 */
	COLUMN_1("In"),
	/**
	 * out
	 */
	COLUMN_2("out");

	private String name;

	InOutStatus(String columnHead) {
		this.name = columnHead;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

}
