package com.marlabs.roster.exception;

/**
 * @author Sushanta.Dehury
 *
 */
public class CurrentMonthNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public CurrentMonthNotFoundException() {
	}

	/**
	 * @param message
	 */
	public CurrentMonthNotFoundException(String message) {
		super(message);
	}

}
