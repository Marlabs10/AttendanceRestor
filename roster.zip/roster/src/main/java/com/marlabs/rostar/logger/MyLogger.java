package com.marlabs.rostar.logger;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * @author Narayan.Dutta
 *
 */
public class MyLogger {

	 static Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	 static FileHandler fh = null;
	 static SimpleFormatter sf = null;
	
	/**
	 * Setting log 
	 * @throws IOException 
	 * 
	 */
	 
	public static void setup() throws IOException{
		
			fh= new FileHandler("AttendanceRoster/logs/log.log");
			sf = new SimpleFormatter();
			fh.setFormatter(sf);
			logger.addHandler(fh);
		
	}
	
}
